from setuptools import setup

with open('README.md') as f:
    long_description = f.read()
setup(version = '0.1.1', long_description=long_description, long_description_content_type='text/markdown')